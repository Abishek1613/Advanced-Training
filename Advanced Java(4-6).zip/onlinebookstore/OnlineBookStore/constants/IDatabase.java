package constants;

public class IDatabase {

	public static final String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
	public static final String CONNECTION_STRING = "jdbc:mysql://localhost:8081/BookStore";
	public static final String USER_NAME = "root";
	public static final String PASSWORD = "root";

}
